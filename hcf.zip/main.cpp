#include<iostream>
using namespace std;

int main(){
    
    int a,b, i =1 , HCF=1;
    cout<<"Enter the first number:";
    cin>>a;
    
    cout<<"Enter the second number:";
    cin>>b;
    
    while(i<=a && i<=b)
    {
        if(a%i == 0 && b%i == 0)
        {
            HCF = i;
        }
        i++;
    }
    cout<<"HCF="<<HCF;
    
    
    
    return 0;
}