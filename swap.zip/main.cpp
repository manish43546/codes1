#include <iostream>
using namespace std;

void sortAndCount(int arr[], int n) {
    int left = 0, right = n - 1;
    int countZero = 0, countOne = 0;

    // Two pointer se sort karna
    while(left < right) {

        while(arr[left] == 0 && left < right) {
            left++;
        }

        while(arr[right] == 1 && left < right) {
            right--;
        }

        if(left < right) {
            swap(arr[left], arr[right]);
            left++;
            right--;
        }
    }

    // Count karna
    for(int i = 0; i < n; i++) {
        if(arr[i] == 0) countZero++;
        else countOne++;
    }

    // Output
    cout << "Sorted array: ";
    for(int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    cout << "Number of 0s: " << countZero << endl;
    cout << "Number of 1s: " << countOne << endl;
}

int main() {
    int arr[] = {1, 0, 1, 0, 1, 0, 0, 1};
    int n = 8;

    sortAndCount(arr, n);

    return 0;
}