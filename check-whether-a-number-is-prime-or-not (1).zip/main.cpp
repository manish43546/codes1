#include <iostream>
using namespace std;

int main()
{
    int number, i = 2;
    bool isPrime = true;

    cout << "Enter a number: ";
    cin >> number;

    // Numbers less than or equal to 1 are not prime
    if (number <= 1)
    {
        isPrime = false;
    }

    while (i < number)
    {
        if (number % i == 0)
        {
            isPrime = false;
            break;
        }

        i++;
    }

    if (isPrime)
    {
        cout << number << " is a Prime Number.";
    }
    else
    {
        cout << number << " is Not a Prime Number.";
    }

    return 0;
}